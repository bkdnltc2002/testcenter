public class Van extends Fleet{
    private static double Wear_and_Tear_Rate=0.6;

    public Van(int year, String reg_num, String make, String model) {
        super(year, reg_num, make, model);
    }

    public double calculateWearAndTear(double distance){
        return Wear_and_Tear_Rate*distance;
    }

    public double calculateProfit(double distance){
        return this.calculateWearAndTear(distance)/2;
    }

    public String toString(){
        return "Van: "+super.toString();
    }
}
