public class Fleet {
    private int  usage_info, year, last_service, service_interval;
    private String reg_num, make, model;

    public Fleet(int year, String reg_num, String make, String model) {
        this.year = year;
        this.reg_num = reg_num;
        this.make = make;
        this.model = model;
    }

    public Fleet() {
    }

    public int getYear() {
        return year;
    }

    public String getReg_num() {
        return reg_num;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public String toString(){
        return String.format("Reg_Number: %sw, Make: %s, Model: %s, Year:%s", reg_num,make,model,year);
    }

}
