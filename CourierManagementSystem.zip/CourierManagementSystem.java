class CourierManagementSystem{
    Fleet V2= new Fleet(2009,"v2", "Volkswagen", "Routan S");
    Fleet v1= new Fleet();
    Fleet t2= new Fleet();
    Fleet t1= new Fleet();
}