public class ServiceHistory {
    private int  usage_info, last_service, service_interval;

    public ServiceHistory(int usage_info, int last_service, int service_interval) {
        this.usage_info = usage_info;
        this.last_service = last_service;
        this.service_interval = service_interval;
    }

    public ServiceHistory() {
    }

    public int getUsage_info() {
        return usage_info;
    }

    public int getLast_service() {
        return last_service;
    }

    public int getService_interval() {
        return service_interval;
    }

    public String toString(){
        return String.format("Service History: Odometer: %.2f km, Last Service: %.2f km, Service Interval: %.2f km", usage_info,last_service,service_interval);
    }

}
