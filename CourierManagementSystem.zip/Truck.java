public class Truck extends Fleet {
    private int load_capicity;
    private static double Wear_and_Tear_Rate=0.5;

    public Truck(int year, String reg_num, String make, String model, int load_capicity) {
        super(year, reg_num, make, model);
        this.load_capicity = load_capicity;
    }

    public int getLoad_capicity() {
        return load_capicity;
    }

    public double calculateWearAndTear(double distance){
        return Wear_and_Tear_Rate*load_capicity*distance;
    }

    public double calculateProfit(double distance){
        return this.calculateWearAndTear(distance)/2;
    }

    public String toString(){
        return "Truck: "+super.toString();
    }
}
